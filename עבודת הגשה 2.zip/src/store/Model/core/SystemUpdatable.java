package store.Model.core;

public interface SystemUpdatable {
    void update();

}
