/**
 * Submitted by:
 * Maayan Gueta – ID 327554143
 * Avishag Almakaies – ID 325684678
 */
package store.Model.orders;

public enum OrderStatus {
    NEW, PAID, SHIPPED, DELIVERED
}
